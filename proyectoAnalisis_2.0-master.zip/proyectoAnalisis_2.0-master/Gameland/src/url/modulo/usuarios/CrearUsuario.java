/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package url.modulo.usuarios;

import javax.persistence.EntityManagerFactory;
import javax.swing.JTable;
import url.conexionBD.Conexion;

/**
 *
 * @author PAOLITA
 */
public class CrearUsuario {
    //Recibir info de jPaneUSuarios
   //Obtener tabla usuarios
    //velificar si ya existe el username
    //Devolver valor (1) exito, (0) failed.
   //insertar a tabla usuarios  
    //Devolver valor (1) exito, (0) failed.
    public void validarusuarios(JTable datosusuarios){
    
    }
    
}
