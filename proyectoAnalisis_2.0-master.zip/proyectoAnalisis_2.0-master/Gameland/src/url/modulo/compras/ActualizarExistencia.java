
package url.modulo.compras;

import javax.swing.JTable;
import url.controlador.ProductoJpaController;
import url.controladorBD.Producto;
public interface ActualizarExistencia {
    public void actualizar(JTable tablaproducto);
}
