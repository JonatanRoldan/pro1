
package url.moculo.ventas;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class AgregarTablaVenta implements AgregarVenta{

    @Override
    public DefaultTableModel obtenerModelo(TableModel modeloProducto, DefaultTableModel modeloDetalle, int seleccion, int cantidad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
